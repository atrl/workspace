import os,sys,json,hashlib,pickle
from pathlib import Path
os.environ['MLFLOW_ALLOW_FILE_STORE']='true'
sys.path.insert(0,'/Users/rziiiii/dev/workspace')
import numpy as np,pandas as pd
import qlib
from qlib.data import D
from qlib.workflow import R
root=Path('/Users/rziiiii/dev/workspace');card=root/'research/soxx_extended_history_20261009'
sha=lambda p:hashlib.sha256(Path(p).read_bytes()).hexdigest()
def tree(p):return {x.relative_to(p).as_posix():sha(x) for x in sorted(p.rglob('*')) if x.is_file()}
plan=json.loads((card/'plan.json').read_text());s=json.loads((card/'summary.json').read_text());binding=json.loads((card/'run_binding.json').read_text());cfg=plan['capture'];cut=pd.Timestamp(cfg['as_of']);fields=['open','high','low','close','volume']
assert s['recorder_id']=='3a89651f93ac4272b60b7ff6feec2f2a'
assert sha(card/'plan.json')==s['plan_sha256']==binding['plan_sha256']
source_hashes={name:sha(root/name) for name in s['source_sha256']};assert source_hashes==s['source_sha256']==binding['source_sha256']
summary_initial_sha=sha(card/'summary.json')
rawdir=root/cfg['raw_dir'];raw_before=tree(rawdir);manifest=json.loads((rawdir/'manifest.json').read_text());receipts=manifest['raw_responses'];assert manifest['read_only'] is True and manifest['request_contract']==cfg
assert len(receipts)==8 and [x['name'] for x in receipts]==['SOXX_rehab_before',*[f'SOXX_history_page_{i}' for i in range(1,7)],'SOXX_rehab_after']
assert pd.Timestamp(plan['registered_at_utc'])<pd.Timestamp(manifest['started_at_utc'])
responses=[];end=pd.Timestamp(manifest['started_at_utc']);request_audit=[]
for receipt in receipts:
 requested,received=map(pd.Timestamp,[receipt['requested_at_utc'],receipt['received_at_utc']])
 assert requested.tzinfo is not None and received.tzinfo is not None and end<=requested<=received
 end=received;path=rawdir/receipt['response_path'];assert path.parent==rawdir and sha(path)==receipt['response_sha256']
 obj=pickle.loads(path.read_bytes());assert obj[0]==receipt['ret']==0 and isinstance(obj[1],pd.DataFrame) and len(obj[1])==receipt['rows']
 responses.append(obj);request_audit.append({'name':receipt['name'],'sha256':receipt['response_sha256'],'rows':receipt['rows'],'requested_at_utc':str(requested),'received_at_utc':str(received),'ret':0})
assert end<=pd.Timestamp(manifest['finished_at_utc'])
pd.testing.assert_frame_equal(responses[0][1],responses[-1][1],check_exact=True)
assert receipts[0]['params']==receipts[-1]['params']=={'code':'US.SOXX'}
chunks=[]
for i,(receipt,response) in enumerate(zip(receipts[1:-1],responses[1:-1]),1):
 expected={k:cfg[k] for k in ['code','requested_start','requested_end','ktype','autype','fields','session','extended_time','max_count']};expected.update(page_number=i,has_prior_page_key=i>1)
 assert receipt['params']==expected and len(response)==3 and bool(response[2])==(i<6)
 assert response[1].code.eq('US.SOXX').all();chunks.append(response[1])
raw=pd.concat(chunks,ignore_index=True);dates=pd.DatetimeIndex(pd.to_datetime(raw.time_key));assert len(raw)==5021 and dates.is_monotonic_increasing and not dates.has_duplicates and dates.tz is None and dates.equals(dates.normalize())
assert dates[0]==pd.Timestamp('2006-10-10') and dates[-1]==cut and (dates<=cut).all()
observed=raw[fields].to_numpy(float)
def physical(values):return bool(np.isfinite(values).all() and (values>0).all() and ((values[:,2]<=values[:,0])&(values[:,0]<=values[:,1])&(values[:,2]<=values[:,3])&(values[:,3]<=values[:,1])).all())
assert physical(observed)
parent_provider=root/plan['parent']['provider_uri'];new_provider=root/plan['outputs']['provider_uri'];parent_before=tree(parent_provider);new_before=tree(new_provider)
# Independent native reference dates; earlier VVIX values are never consumed.
cal=root/plan['calendar']['provider_uri'];assert sha(cal/'calendars/day.txt')==plan['calendar']['calendar_file_sha256'];assert sha(cal/'qlib_store_manifest.json')==plan['calendar']['store_manifest_sha256']
qlib.init(provider_uri=str(cal),region='us',kernels=1);reference=pd.DatetimeIndex(D.calendar(freq='day',future=False));reference=reference[(reference>=dates[0])&(reference<=cut)]
assert reference.equals(dates) and hashlib.sha256('\n'.join(reference.strftime('%Y-%m-%d')).encode()).hexdigest()==plan['calendar']['selected_dates_sha256']
# All six parent digests must match their old manifest before any parent object load.
ps=json.loads((root/plan['parent']['summary']).read_text());pc=(root/plan['parent']['summary']).parent;pm=json.loads((pc/'artifact_manifest.json').read_text());parent_artifacts={}
assert ps['recorder_id']==pm['recorder_id']==plan['parent']['recorder_id']
for name,digest in plan['parent']['artifact_sha256'].items():
 file=Path(ps['recorder_local_dir'])/'artifacts'/name;records=[e for e in pm['entries'] if (root/e['path']).resolve()==file.resolve()]
 assert len(records)==1 and records[0]['sha256']==sha(file)==digest;parent_artifacts[name]=digest
qlib.init(provider_uri=str(parent_provider),region='us',kernels=1)
old_native=D.features(['SOXX'],['$'+f for f in fields],start_time=plan['parent']['overlap_start'],end_time=cut,freq='day')
with R.uri_context(ps['recorder_uri']):
 parent=R.get_recorder(experiment_name=ps['experiment'],recorder_id=ps['recorder_id']);assert parent.client.get_run(parent.id).info.status=='FINISHED'
 old_raw=parent.load_object('inputs/verified_raw_inputs.pkl');old_qualified=parent.load_object('data/qualified_frame.pkl')
# Independently compose published affine and exact share operators, no project transform call.
rehab=responses[0][1];event_dates=pd.to_datetime(rehab.ex_div_date);assert not event_dates.isna().any() and not event_dates.duplicated().any()
events=[]
for row in rehab.to_dict('records'):
 event=pd.Timestamp(row['ex_div_date']);a=float(row['forward_adj_factorA']);b=float(row['forward_adj_factorB']);assert np.isfinite([a,b]).all() and a>0
 ratios=[]
 for prefix in ('split','join'):
  numerator,denominator=row.get(prefix+'_base',np.nan),row.get(prefix+'_ert',np.nan)
  if pd.isna(numerator) and pd.isna(denominator):continue
  assert np.isfinite([numerator,denominator]).all() and numerator>0 and denominator>0
  ratios.append(float(numerator/denominator))
 assert len(ratios)<=1
 for prefix in ('bonus','transfer','allot','add','spin_off'):
  assert pd.isna(row.get(prefix+'_base',np.nan)) and pd.isna(row.get(prefix+'_ert',np.nan))
 if not ratios and pd.notna(row.get('split_ratio',np.nan)):assert float(row['split_ratio'])==1.
 events.append((event,a,b,ratios[0] if ratios else 1.))
events.sort();A=np.ones(len(raw));B=np.zeros(len(raw));split=np.ones(len(raw));applied=np.zeros(len(raw),int)
for event,a,b,ratio in events:
 if event<=cut:
  mask=dates<event;A[mask]*=a;B[mask]=B[mask]*a+b;split[mask]*=ratio;applied[mask]+=1
transformed=np.c_[observed[:,:4]*A[:,None]+B[:,None],observed[:,4]/split]
assert physical(transformed)
old_events=old_raw['none']['rehabilitation']['SOXX'];used=['ex_div_date','forward_adj_factorA','forward_adj_factorB','split_base','split_ert','join_base','join_ert']
pd.testing.assert_frame_equal(rehab.loc[event_dates<=cut,used].sort_values('ex_div_date').reset_index(drop=True),old_events.loc[pd.to_datetime(old_events.ex_div_date)<=cut,used].sort_values('ex_div_date').reset_index(drop=True),check_exact=True)
overlap=dates>=pd.Timestamp(plan['parent']['overlap_start']);early=~overlap;assert overlap.sum()==4162 and early.sum()==859
old_bars=old_raw['none']['frame'].loc[old_raw['none']['frame'].code.eq('US.SOXX')]
assert pd.DatetimeIndex(pd.to_datetime(old_bars.time_key)).equals(dates[overlap]);np.testing.assert_array_equal(old_bars[fields].to_numpy(float),observed[overlap])
old_q=old_qualified.loc[old_qualified.instrument.eq('SOXX')];assert pd.DatetimeIndex(old_q.datetime).equals(dates[overlap]);np.testing.assert_array_equal(old_q[fields].to_numpy(float),transformed[overlap])
# New complete provider and exact old overlap via Qlib native API.
qlib.init(provider_uri=str(new_provider),region='us',kernels=1);new_calendar=pd.DatetimeIndex(D.calendar(freq='day',future=False));assert new_calendar.equals(dates)
assert D.list_instruments(D.instruments('all'),as_list=True)==['SOXX']
new_native=D.features(['SOXX'],['$'+f for f in fields],start_time=dates[0],end_time=cut,freq='day')
assert len(new_native)==5021;np.testing.assert_array_equal(new_native.to_numpy(),transformed.astype(np.float32));np.testing.assert_array_equal(new_native.loc[new_native.index.get_level_values('datetime')>=plan['parent']['overlap_start']].to_numpy(),old_native.to_numpy())
assert len(list((new_provider/'features').rglob('*.bin')))==5
# Formal new Recorder and retained initial run must carry identical source/price objects.
new_objects={};new_object_sha={};retained_old='0df539b390de47c894a007404ce5d7da'
with R.uri_context(s['recorder_uri']):
 newrec=R.get_recorder(experiment_name=s['experiment'],recorder_id=s['recorder_id']);assert newrec.client.get_run(newrec.id).info.status=='FINISHED'
 art=Path(newrec.get_local_dir())/'artifacts';assert art.parent==Path(s['recorder_local_dir'])
 for name,digest in source_hashes.items():assert sha(art/'source'/name)==digest
 for name in ['inputs/parent_bindings.pkl','inputs/verified_capture.pkl','data/transformed_frame.pkl','data/qualification.pkl','data/native_readback.pkl']:
  new_object_sha[name]=sha(art/name);new_objects[name]=newrec.load_object(name)
 oldrec=R.get_recorder(experiment_name=s['experiment'],recorder_id=retained_old);assert oldrec.client.get_run(oldrec.id).info.status=='FINISHED'
 old_frame=oldrec.load_object('data/transformed_frame.pkl');old_binding=oldrec.load_object('inputs/parent_bindings.pkl');old_qual=oldrec.load_object('data/qualification.pkl');old_readback=oldrec.load_object('data/native_readback.pkl')
assert new_objects['inputs/parent_bindings.pkl']==binding
pd.testing.assert_frame_equal(new_objects['inputs/verified_capture.pkl']['frame'],raw,check_exact=True)
newframe=new_objects['data/transformed_frame.pkl'];np.testing.assert_array_equal(newframe[fields].to_numpy(float),transformed)
np.testing.assert_array_equal(newframe.affine_A.to_numpy(float),A);np.testing.assert_array_equal(newframe.affine_B.to_numpy(float),B);np.testing.assert_array_equal(newframe.split_price_factor.to_numpy(float),split);np.testing.assert_array_equal(newframe.rehab_event_count.to_numpy(),applied)
pd.testing.assert_frame_equal(newframe,old_frame,check_exact=True)
assert new_objects['data/qualification.pkl']==old_qual
assert old_binding['plan_sha256']==binding['plan_sha256'] and old_binding['capture']==binding['capture']
assert old_readback['frame_sha256']==new_objects['data/native_readback.pkl']['frame_sha256']
assert old_readback['provider_file_sha256']==new_objects['data/native_readback.pkl']['provider_file_sha256']==new_before
assert new_objects['data/native_readback.pkl']['immutable_provider_reused'] is True and old_readback['immutable_provider_reused'] is False
assert parent_before==tree(parent_provider)==binding['parent']['provider_file_sha256'];assert new_before==tree(new_provider);assert raw_before==tree(rawdir)
for name,digest in parent_artifacts.items():assert sha(Path(ps['recorder_local_dir'])/'artifacts'/name)==digest
for name,digest in new_object_sha.items():assert sha(art/name)==digest
assert {name:sha(root/name) for name in source_hashes}==source_hashes
new_summary=json.loads((card/'summary.json').read_text())
for key in ['recorder_id','plan_sha256','source_sha256','provider_uri','as_of','rows','new_early_rows','parent_overlap_rows','immutable_provider_reused']:assert new_summary[key]==s[key]
result={'status':'passed','recorder_id':s['recorder_id'],'retained_initial_recorder_id':retained_old,'recorders_FINISHED':True,
 'plan_sha256':s['plan_sha256'],'source_sha256':source_hashes,'summary_initial_sha256':summary_initial_sha,'summary_final_sha256':sha(card/'summary.json'),
 'raw_capture':{'manifest_sha256':sha(rawdir/'manifest.json'),'explicit_requests':len(receipts),'history_pages':6,'page_rows':[len(x) for x in chunks],'chronological_bracketing_pass':True,'before_after_rehab_exact':True,'rehab_rows':len(rehab),'requests':request_audit,'no_new_Futu_API_requests_by_audit':True},
 'source_qualification':{'total_rows':len(raw),'early_rows':int(early.sum()),'overlap_rows':int(overlap.sum()),'start':str(dates[0].date()),'end':str(dates[-1].date()),'early_end':str(dates[early][-1].date()),'raw_ohlcv_physical':True,'adjusted_ohlcv_physical':True,'new_rows_dropped':0,'new_rows_filled':0,'raw_overlap_float64_bitwise_equal':True,'published_overlap_float64_bitwise_equal':True,'independent_affine_transform_float64_bitwise_equal':True,'split_volume_transform_float64_bitwise_equal':True,'early_raw_minimum_price':float(observed[early,:4].min()),'early_raw_minimum_volume':float(observed[early,4].min()),'early_transformed_minimum_price':float(transformed[early,:4].min()),'early_transformed_minimum_volume':float(transformed[early,4].min()),'calendar_reference_exact':True},
 'native_qualification':{'universe':['SOXX'],'rows':len(new_native),'field_files':5,'native_D_readback_float32_bitwise_equal':True,'old_4162_native_rows_bitwise_equal':True,'provider_reused_without_changes':True},
 'new_old_recorders':{'transformed_frames_exact':True,'qualification_objects_exact':True,'same_plan_and_capture':True,'same_native_frame_hash':True,'same_provider_file_hashes':True,'data_and_transforms_unchanged_after_publication_guard_repair':True},
 'new_artifact_sha256':new_object_sha,'parent_artifact_sha256':parent_artifacts,'parent_provider_files_unchanged':True,'raw_files_unchanged':True,
 'qualification':'SOXX-only retrospective published-affine history qualifies under declared source and native-readback contract',
 'not_proven':['SOXX inception through2006-10-09 remains missing','No pre-inception SOXL prices/features/labels were constructed','No exact SDK QFQ or total-return/cash-distribution accounting equivalence','No independently authenticated exchange ground-truth or historical-PIT certification','Cboe retrospective dates are a session reference; early VVIX values were not used as predictive features','No new forward investment evidence, model fit, forecast, backtest, alpha or promotion qualification'],
 'scope':'Read existing decoded SDK receipts, hash-verified Recorder objects and native Qlib data; independent arithmetic only, no service/broker API request, model or portfolio execution.'}
Path('/tmp/soxx-extended-independent-audit.json').write_text(json.dumps(result,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':result['status'],'recorder_id':result['recorder_id'],'source_qualification':result['source_qualification'],'native_qualification':result['native_qualification'],'new_old_recorders':result['new_old_recorders']},indent=2))
