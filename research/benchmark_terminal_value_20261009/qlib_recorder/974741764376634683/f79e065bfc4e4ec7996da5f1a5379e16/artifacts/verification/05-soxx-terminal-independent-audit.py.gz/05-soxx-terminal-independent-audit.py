import os,sys,json,hashlib,gzip,pickle
from pathlib import Path
from collections import Counter
os.environ['MLFLOW_ALLOW_FILE_STORE']='true'
sys.path.insert(0,'/Users/rziiiii/dev/workspace')
import numpy as np,pandas as pd
import qlib
from qlib.data import D
from qlib.workflow import R
from src.core.recorder_sources import load_verified_recorder_objects
from src.data.integrated_allocation import frame_sha256
root=Path('/Users/rziiiii/dev/workspace');card=root/'research/benchmark_terminal_value_20261009'
sha=lambda path:hashlib.sha256(Path(path).read_bytes()).hexdigest()
summary_bytes=(card/'summary.json').read_bytes();s=json.loads(summary_bytes)
plan_bytes=(card/'plan.json').read_bytes();plan=json.loads(plan_bytes)
binding_bytes=(card/'run_binding.json').read_bytes();binding=json.loads(binding_bytes)
assert sha(card/'plan.json')==s['plan_sha256']==binding['plan_sha256']
assert sha(card/'run_binding.json')==s['run_binding_sha256']
assert s['model_fits']==plan['model_fit_budget']==0 and not s['promotion_eligible']
source_checks={}
for name,digest in s['source_sha256'].items():
 assert sha(root/name)==digest,(name,'working source changed')
 source_checks[name]=digest
qlib.init(provider_uri=str(root/s['execution_provider_uri']),region='us',kernels=1)
loaded={};artifact_sha={}
with R.uri_context(s['recorder_uri']):
 rec=R.get_recorder(experiment_name=s['experiment'],recorder_id=s['recorder_id'])
 assert rec.client.get_run(rec.id).info.status=='FINISHED'
 local=Path(rec.get_local_dir());art=local/'artifacts'
 assert local==Path(s['recorder_local_dir'])
 for name,digest in source_checks.items():assert sha(art/'source'/name)==digest,(name,'archived source differs')
 names=['inputs/plan.pkl','inputs/binding.pkl','inputs/frame.pkl','forecast/frozen_parent.pkl','analysis/paths.pkl','analysis/raw_gates.pkl','analysis/gates.pkl']
 for name in names:artifact_sha[name]=sha(art/name)
 for name in names:loaded[name]=rec.load_object(name)
 for identity in s['compressed_artifacts']:
  name=identity['artifact'];packed=(art/name).read_bytes();assert hashlib.sha256(packed).hexdigest()==identity['sha256']
  raw=gzip.decompress(packed);assert hashlib.sha256(raw).hexdigest()==identity['uncompressed_sha256']
  artifact_sha[name]=identity['sha256'];loaded[name]=pickle.loads(raw)
 for name,digest in artifact_sha.items():assert sha(art/name)==digest
 assert rec.client.get_run(rec.id).info.status=='FINISHED'
assert loaded['inputs/plan.pkl']==plan and loaded['inputs/binding.pkl']==binding
parents,parent_audit=load_verified_recorder_objects(root/plan['parent']['card'],expected_recorder_id=plan['parent']['recorder_id'],artifacts=list(plan['parent']['artifact_sha256']),expected_artifact_sha256=plan['parent']['artifact_sha256'])
assert parent_audit==binding['verified_parent']
frame=loaded['inputs/frame.pkl'];pd.testing.assert_frame_equal(frame,parents['inputs/frame.pkl'],check_exact=True)
assert frame_sha256(frame)==binding['bundle_identity']['frame_sha256']
frozen=loaded['forecast/frozen_parent.pkl'];parent_frozen=parents['forecast/forecasts.pkl'][plan['parent']['forecast_variant']]
pd.testing.assert_frame_equal(frozen['rows'],parent_frozen['rows'],check_exact=True);np.testing.assert_array_equal(frozen['Vmean'],parent_frozen['Vmean'])
market=frame.loc[(frame.index>=pd.Timestamp(plan['signal_start']))&frame.exit_date.notna()]
assert frozen['rows'].index.equals(market.index)
mu=frozen['rows'][['predicted_soxl','predicted_soxx']].to_numpy(float);V=frozen['Vmean']
paths=loaded['analysis/paths.pkl'];native=loaded['portfolio_analysis/native_reports.pkl.gz'];solves=loaded['analysis/solver_details.pkl.gz'];terminal=loaded['analysis/terminal_valuation_details.pkl.gz']
assert set(paths)==set(native)=={(name,cost) for name in ('soxx','selected_original','benchmark_terminal') for cost in (10.,25.)}
calendar=pd.DatetimeIndex(D.calendar(freq='day',future=False));assert str(calendar[-1].date())==s['as_of']
open_prices=D.features(['SOXL','SOXX'],['$open'],start_time=calendar[0],end_time=s['as_of'],freq='day')['$open'].unstack('instrument').reindex(calendar)[['SOXL','SOXX']].astype(float)
assert np.isfinite(open_prices.to_numpy()).all()
market_returns=open_prices.reindex(market.exit_date).to_numpy()/open_prices.reindex(market.trade_date).to_numpy()-1
np.testing.assert_array_equal(market_returns,market[['soxl_return','soxx_return']].to_numpy(float))
market_dates=market[['signal_date','trade_date','exit_date']].reset_index(drop=True)
raw_open_returns=open_prices.to_numpy()[1:]/open_prices.to_numpy()[:-1]-1
sigma_cache={}
for i in range(0,len(market),5):
 location=calendar.get_loc(market.index[i]);sigma_cache[i]=np.cov(raw_open_returns[:location].T,ddof=1)
path_audits=[];native_funded={}
for key,path in paths.items():
 name,cost=key;assert path[['signal_date','trade_date','exit_date']].equals(market_dates)
 assert path.cost_bps.eq(cost).all()
 positions=native[key]['positions'];assert len(positions)==len(path)==len(native[key]['report'])
 prev_qty=np.zeros(2);prev_cash=float(plan['initial_cash']);maxima={k:0. for k in ('return','fees','turnover','open_weights','pretrade_weights','ending_weights','native_reconciliation_return','hold_amount','hold_cash')};funded=[]
 for i,row in enumerate(path.itertuples()):
  position=positions[row.trade_date];owned=position.get_stock_amount_dict();qty=np.array([owned.get('SOXL',0.),owned.get('SOXX',0.)],float);cash=float(position.get_cash())
  opening=open_prices.loc[row.trade_date].to_numpy();exit_open=open_prices.loc[row.exit_date].to_numpy()
  prevalues=np.r_[prev_qty*opening,prev_cash];pre_nav=prevalues.sum()
  postvalues=np.r_[qty*opening,cash];post_nav=postvalues.sum()
  notional=(qty-prev_qty)*opening;fee=(prev_cash-cash-notional.sum())/pre_nav;turnover=np.abs(notional).sum()/pre_nav
  nextvalues=np.r_[qty*exit_open,cash];next_nav=nextvalues.sum();net=next_nav/pre_nav-1
  checks={'return':abs(net-row.strategy_return),'fees':abs(fee-row.fees),'turnover':abs(turnover-row.turnover),
    'pretrade_weights':np.max(np.abs(prevalues/pre_nav-np.array([getattr(row,f'pretrade_{a}_weight') for a in ('soxl','soxx','cash')]))),
    'open_weights':np.max(np.abs(postvalues/post_nav-np.array([getattr(row,f'open_{a}_weight') for a in ('soxl','soxx','cash')]))),
    'ending_weights':np.max(np.abs(nextvalues/next_nav-np.array([getattr(row,f'ending_{a}_weight') for a in ('soxl','soxx','cash')]))),
    'native_reconciliation_return':abs(net-float(native[key]['reconciliation'].native_next_open_return.iloc[i]))}
  assert abs(fee-turnover*cost/10000.)<1e-10
  if not row.execute_open_target:
   checks['hold_amount']=np.max(np.abs(qty-prev_qty));checks['hold_cash']=abs(cash-prev_cash)
  for label,error in checks.items():maxima[label]=max(maxima[label],float(error))
  funded.append(postvalues/pre_nav)
  prev_qty,prev_cash=qty,cash
 assert max(maxima.values())<=1e-9,(key,maxima)
 native_funded[key]=np.array(funded)
 path_audits.append({'strategy':name,'cost_bps':cost,'sessions':len(path),'maximum_absolute_errors':maxima,'passed':True})
# Saved solver evidence and inputs, without invoking any optimization.
certificate_fields=['primal_residual_abs','dual_residual_abs','primal_cone_violation','dual_cone_violation','absolute_duality_gap','primal_objective_identity_error','dual_objective_identity_error','reported_primal_residual','reported_dual_residual']
solver_audits=[];stage_counts=Counter();total=0;q_errors=[]
for key,details in solves.items():
 name,cost=key;path=paths[key];expected_indices=list(np.flatnonzero(path.optimizer_called))
 assert [x['row_number'] for x in details]==expected_indices==list(range(0,len(path),5))
 errors={k:0. for k in ('mean','uncertainty','covariance','target','funded','risk_violation','scaled_objective','reported_penalty')}
 for item in details:
  i=item['row_number'];result=item['solution'];row=path.iloc[i];a=result['solver_audit'];cert=a['numerical_certificate']
  assert result['optimality_verified'] is True and cert['all_checks_pass'] is True
  assert cert['raw_status'] in ('Solved','AlmostSolved') and cert['tolerance']==1e-8
  assert all(np.isfinite(cert[f]) and abs(cert[f])<=1e-8 for f in certificate_fields)
  assert a['tolerance']==1e-8 and a['solver_tolerance']==1e-10 and result['cost_bps']==cost and result['forecast_horizon_sessions']==5
  assert result['budget_mode']=='same_soxx' and a['robust_radius']==1.
  assert abs(a['exact_funded_wealth_to_numerical_dual_bound_gap'])<=1e-8
  attempts=a['numerical_attempts'];assert attempts[-1]['certificate']['all_checks_pass']
  assert all(not x['certificate']['all_checks_pass'] for x in attempts[:-1])
  for attempt in attempts:
   assert attempt['certificate']['tolerance']==1e-8
   options=attempt.get('solver_options',{})
   for setting in ('tol_gap_abs','tol_gap_rel','tol_feas'):assert options.get(setting,1e-10)==1e-10
  stage_counts[attempts[-1].get('numerical_method','original')]+=1
  assert pd.Timestamp(item['signal_date'])==row.signal_date
  assert pd.Timestamp(item['decision_at'])==pd.Timestamp(row.decision_at)
  scale=1/(1+cost/10000.);diagonal=np.array([1-cost/10000.,1+cost/10000.])
  expected_mu=mu[i] if name=='selected_original' else mu[i]*diagonal+[-cost/10000.,cost/10000.]
  expected_V=V[i] if name=='selected_original' else diagonal[:,None]*V[i]*diagonal[None,:]
  errors['mean']=max(errors['mean'],float(np.max(abs(result['expected_returns_H']-expected_mu))))
  errors['uncertainty']=max(errors['uncertainty'],float(np.max(abs(result['mean_error_covariance_H']-expected_V))))
  errors['covariance']=max(errors['covariance'],float(np.max(abs(result['covariance_daily']-sigma_cache[i]))))
  weights=row[[f'open_{a}_weight' for a in ('soxl','soxx','cash')]].to_numpy(float)
  errors['target']=max(errors['target'],float(np.max(abs(result['target_net_weights']-weights))))
  x=native_funded[key][i];errors['funded']=max(errors['funded'],float(np.max(abs(result['post_fee_values']-x))))
  risk=float(weights[:2]@sigma_cache[i]@weights[:2]/sigma_cache[i][1,1]-1.)
  errors['risk_violation']=max(errors['risk_violation'],max(0.,risk));assert risk<=1e-8
  d=x[:2]-x.sum()*np.array([0.,1.]);penalty=float(np.sqrt(max(0.,d@expected_V@d)))
  errors['reported_penalty']=max(errors['reported_penalty'],abs(result['robust_penalty']-penalty))
  if name=='benchmark_terminal':
   direct=x[1]*(1+mu[i,1])+(x[2]+(1-cost/10000.)*x[0]*(1+mu[i,0]))/(1+cost/10000.)
   err=abs(scale*result['objective']-(direct-scale*penalty));q_errors.append(err);errors['scaled_objective']=max(errors['scaled_objective'],err)
  total+=1
 assert max(errors.values())<1e-9,(key,errors)
 solver_audits.append({'strategy':name,'cost_bps':cost,'solves':len(details),'maximum_absolute_errors':errors,'passed':True})
# Parent forecast-control reproduction.
parent_checks=[]
for cost in (10.,25.):
 current=paths[('selected_original',cost)];previous=parents['analysis/paths.pkl'][('validation_selected',cost)]
 pd.testing.assert_frame_equal(current,previous,check_exact=True)
 parent_checks.append({'cost_bps':cost,'full_dataframe_exact_equal':True})
# Raw estimates and resolved classifications from retained returns, no sampling.
raw=loaded['analysis/raw_gates.pkl']['benchmark_terminal'];resolved=loaded['analysis/gates.pkl']['benchmark_terminal']
for name in ('metrics','annual','bootstrap'):
 cols=[c for c in raw[name] if c!='lower_bound_positive'];pd.testing.assert_frame_equal(raw[name][cols],resolved[name][cols],check_exact=True)
classification=[]
for cost in (10.,25.):
 path=paths[('benchmark_terminal',cost)];bench=paths[('soxx',cost)];mask=path.signal_date.dt.year.isin(plan['development_years'])
 difference=np.log1p(path.loc[mask,'strategy_return'].to_numpy())-np.log1p(bench.loc[mask,'strategy_return'].to_numpy())
 dates=path.loc[mask,'signal_date'];annual=np.array([difference[dates.dt.year.to_numpy()==year].sum() for year in plan['development_years']]);rolling=pd.Series(difference).rolling(252,min_periods=252).sum().dropna();leave=annual.sum()-annual;floor=plan['numerical_log_excess_floor']
 g=resolved['gates'].loc[resolved['gates'].cost_bps.eq(cost)].iloc[0];rg=raw['gates'].loc[raw['gates'].cost_bps.eq(cost)].iloc[0]
 assert g.positive_years==int((annual>floor).sum()) and rg.positive_years==int((annual>0).sum())
 assert g.aggregate_positive_net_log_excess==bool(difference.sum()>floor)
 assert g.median_annual_log_excess_positive==bool(np.median(annual)>floor)
 assert g.leave_any_one_year_out_log_excess_positive==bool(leave.min()>floor)
 rr=resolved['rolling_summary'].loc[resolved['rolling_summary'].cost_bps.eq(cost)].iloc[0];assert rr.positive_windows==int((rolling>floor).sum())
 assert rr.positive_excess_rate==float((rolling>floor).mean())
 for row in resolved['bootstrap'].loc[resolved['bootstrap'].cost_bps.eq(cost)].itertuples():
  assert row.sessions==len(difference) and row.daily_mean_log_excess==float(difference.mean())
  assert row.lower_bound_positive==bool(len(difference)*row.daily_lower_bound>floor)
 for field in ['anchored_max_drawdown_not_worse_than_soxx','cvar5_not_worse_than_soxx']:assert g[field]==rg[field]
 classification.append({'cost_bps':cost,'sessions':len(difference),'raw_positive_years':int(rg.positive_years),'resolved_positive_years':int(g.positive_years),'within_resolution_years':int((abs(annual)<=floor).sum()),'raw_positive_rolling_windows':int((rolling>0).sum()),'resolved_positive_rolling_windows':int((rolling>floor).sum()),'all_pass':bool(g.all_pass)})
assert resolved['historical_gate_pass']==bool(resolved['gates'].all_pass.all())==s['historical_gate_pass']
# Printed comparison values: independently recompute full path/window effects.
comparison=pd.read_csv(card/'backtest_benchmark_comparison.csv');metric_errors=[]
for record in comparison.itertuples():
 p=paths[(record.strategy,record.cost_bps)];b=paths[('soxx',record.cost_bps)];selected=p.signal_date.dt.year.isin(plan['development_years']) if record.window=='development' else p.signal_date.dt.year.gt(2022)
 r=p.loc[selected,'strategy_return'].to_numpy();rb=b.loc[selected,'strategy_return'].to_numpy();log=np.log1p(r);lb=np.log1p(rb);navlog=np.r_[0.,log.cumsum()];ordered=np.sort(r);mass=.05*len(r);whole=int(np.floor(mass));cvar=(ordered[:whole].sum()+(mass-whole)*ordered[whole])/mass
 expected={'relative_wealth':float(np.exp((log-lb).sum())),'return_pct':float(100*np.expm1(log.sum())),'max_drawdown_pct':float(100*np.expm1((navlog-np.maximum.accumulate(navlog)).min())),'cvar5_pct':float(100*cvar),'turnover':float(p.loc[selected,'turnover'].sum())}
 error=max(abs(getattr(record,key)-value) for key,value in expected.items());assert error<1e-8;metric_errors.append(error)
for filename in ['plan.json','run_binding.json','gates.csv','rolling_summary.csv','bootstrap_analysis.csv','raw_gates.csv','raw_rolling_summary.csv','raw_bootstrap_analysis.csv','resolved_metrics.csv','resolved_annual_metrics.csv','valuation_audit.csv','parent_control_reproduction.csv','backtest_benchmark_comparison.csv','annual_metrics.csv']:
 assert (card/filename).read_bytes()==(art/'card'/filename).read_bytes(),filename
for name,digest in artifact_sha.items():assert sha(art/name)==digest
assert summary_bytes==(card/'summary.json').read_bytes() and plan_bytes==(card/'plan.json').read_bytes() and binding_bytes==(card/'run_binding.json').read_bytes()
out={'recorder_id':s['recorder_id'],'status':'passed','model_fits':0,'policy_solves_rerun':0,'bootstrap_resamples_added':0,'source_files_verified':len(source_checks),'parent_artifacts_verified':parent_audit,'artifact_sha256':artifact_sha,'native_positions_independently_valued':path_audits,'saved_solver_certificates_checked':total,'accepted_numerical_stages':dict(stage_counts),'solver_input_and_value_checks':solver_audits,'terminal_objective_checks':{'decisions':len(q_errors),'maximum_absolute_error':max(q_errors)},'parent_control_reproduction':parent_checks,'raw_and_resolved_classification':classification,'sidecar_comparison_maximum_error':max(metric_errors),'historical_gate_pass':s['historical_gate_pass'],'promotion_eligible':False,'scope':'Readback, independent held-quantity/cash/native-price arithmetic and retained certificate checks; no optimizer/model/strategy re-execution and no new statistical sampling. Raw dual vectors are not archived, so residual certificates are checked as retained records rather than recomputed from raw KKT matrices.'}
Path('/tmp/soxx-terminal-independent-audit.json').write_text(json.dumps(out,indent=2,allow_nan=False)+'\n')
print(json.dumps({'status':'passed','native_paths':len(path_audits),'native_rows':sum(x['sessions'] for x in path_audits),'certificates':total,'q_checks':len(q_errors),'q_error':max(q_errors),'classifications':classification},indent=2))
