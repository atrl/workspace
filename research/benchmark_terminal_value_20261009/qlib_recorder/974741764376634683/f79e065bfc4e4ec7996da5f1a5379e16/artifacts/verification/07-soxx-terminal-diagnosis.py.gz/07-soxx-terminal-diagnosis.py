import hashlib
import json
from pathlib import Path

import numpy as np
import pandas as pd
import qlib
from qlib.workflow import R

from src.analysis.allocation_attribution import attribute_allocations
from src.core.recorder_artifacts import load_compressed_object

root = Path('/Users/rziiiii/dev/workspace')
card = root/'research/benchmark_terminal_value_20261009'
out = Path('/tmp/soxx-terminal-diagnosis'); out.mkdir(exist_ok=True)
summary = json.loads((card/'summary.json').read_text())
qlib.init(provider_uri=str(root/summary['provider_uri']), region='us', kernels=1)
with R.uri_context(summary['recorder_uri']):
    rec = R.get_recorder(experiment_name=summary['experiment'], recorder_id=summary['recorder_id'])
    assert rec.client.get_run(rec.id).info.status == 'FINISHED'
    paths = rec.load_object('analysis/paths.pkl')
    frame = rec.load_object('inputs/frame.pkl')
    forecast = rec.load_object('forecast/frozen_parent.pkl')
    solver = load_compressed_object(rec, next(x for x in summary['compressed_artifacts'] if x['artifact']=='analysis/solver_details.pkl.gz'))
market = frame.loc[paths['soxx',10.].signal_date].copy().reset_index(drop=True)
windows = {'development':('2016-01-04','2022-12-31'), 'reused_diagnostic':('2023-01-01','2026-09-25')}
windows.update({str(year):(f'{year}-01-01',f'{year}-12-31') for year in range(2016,2027)})
attribution = attribute_allocations(paths, market, windows=windows)
attribution.to_csv(out/'allocation_attribution.csv', index=False)
episodes, initial, active_decisions = [], [], []
for (name,cost), path in paths.items():
    if name=='soxx': continue
    wcols = ['open_soxl_weight','open_soxx_weight','open_cash_weight']
    weights = path[wcols].to_numpy(float)
    active = np.max(np.abs(weights-np.array([0.,1.,0.])),axis=1)>1e-8
    base = paths['soxx',cost]
    excess = np.log1p(path.strategy_return.to_numpy())-np.log1p(base.strategy_return.to_numpy())
    starts = np.flatnonzero(active & ~np.r_[False,active[:-1]])
    ends = np.flatnonzero(active & ~np.r_[active[1:],False])
    for start,end in zip(starts,ends):
        sl=slice(start,end+1)
        episodes.append({'strategy':name,'cost_bps':cost,'start_signal':str(path.signal_date.iloc[start].date()),
            'last_signal':str(path.signal_date.iloc[end].date()),'last_exit':str(path.exit_date.iloc[end].date()),
            'sessions':end-start+1,'relative_wealth_during_active_hold':float(np.exp(excess[sl].sum())),
            'active_hold_log_excess':float(excess[sl].sum()),'mean_soxl':float(weights[sl,0].mean()),
            'mean_soxx':float(weights[sl,1].mean()),'mean_cash':float(weights[sl,2].mean()),
            'turnover_inside_active_hold':float(path.turnover.iloc[sl].sum()),
            'scope':'exit-to-benchmark cost may occur on next row; full-path metrics remain authoritative'})
    row = path.iloc[0]
    initial.append({'strategy':name,'cost_bps':cost,'signal_date':str(row.signal_date.date()),
        'soxl_weight':row.open_soxl_weight,'soxx_weight':row.open_soxx_weight,'cash_weight':row.open_cash_weight,
        'fee_bp':row.fees*10000,'active_hold_sessions':int(active.sum()),'turnover':float(path.turnover.sum())})
    if name=='benchmark_terminal':
        for item in solver[name,cost]:
            i=item['row_number']; s=item['solution']; r=path.iloc[i]
            if active[i] or (i>0 and active[i-1]):
                f=forecast['rows'].iloc[i]
                active_decisions.append({'cost_bps':cost,'signal_date':str(r.signal_date.date()),
                    'trade_date':str(r.trade_date.date()),'row_number':i,'raw_mu_soxl':f.predicted_soxl,
                    'raw_mu_soxx':f.predicted_soxx,'soxl_weight':r.open_soxl_weight,'soxx_weight':r.open_soxx_weight,
                    'cash_weight':r.open_cash_weight,'fee_bp':r.fees*10000,'solution_source':s['solution_source'],
                    'objective':s['objective'],'robust_penalty':s['robust_penalty']})
pd.DataFrame(episodes).to_csv(out/'active_episodes.csv',index=False)
pd.DataFrame(initial).to_csv(out/'initial_state.csv',index=False)
pd.DataFrame(active_decisions).to_csv(out/'terminal_active_decisions.csv',index=False)
# Explain the one retained active event, using fixed CASH/SOXX alternatives.
# This is arithmetic on frozen inputs, not a new optimization or strategy.
date=pd.Timestamp('2022-05-04'); i=forecast['rows'].index.get_loc(date)
mu_x=float(forecast['rows'].iloc[i].predicted_soxx)
std_x=float(np.sqrt(forecast['Vmean'][i,1,1]))
threshold=[]
for cost in (10.,25.):
    row=paths['benchmark_terminal',cost].iloc[i]
    assert np.allclose(row[['pretrade_soxl_weight','pretrade_soxx_weight','pretrade_cash_weight']].to_numpy(float),[0,1,0],atol=1e-12,rtol=0)
    c=cost/10000
    cash_value=(1-c)/(1+c)-(1-c)*std_x
    soxx_value=1+mu_x
    threshold.append({'signal_date':str(date.date()),'cost_bps':cost,'raw_mu_soxx':mu_x,'raw_mean_std_soxx':std_x,
        'robust_cash_terminal_value':cash_value,'soxx_terminal_value':soxx_value,
        'cash_minus_soxx_planning_bp':(cash_value-soxx_value)*10000,
        'executed_cash_weight':row.open_cash_weight,'scope':'same frozen forecast, actual all-SOXX starting position, fixed null alternatives only'})
pd.DataFrame(threshold).to_csv(out/'event_cost_threshold.csv',index=False)
identity={'recorder_id':rec.id,'parent_recorder_id':summary['parent_recorder_id'],
    'scope':'Read-only recorded paths and posthoc arithmetic; no fit, solve, signal or native replay',
    'diagnostic_source_sha256':hashlib.sha256((root/'src/analysis/allocation_attribution.py').read_bytes()).hexdigest(),
    'artifact_sha256':{name:hashlib.sha256((Path(rec.get_local_dir())/'artifacts'/name).read_bytes()).hexdigest()
        for name in ['analysis/paths.pkl','inputs/frame.pkl','forecast/frozen_parent.pkl','analysis/solver_details.pkl.gz']}}
(out/'provenance.json').write_text(json.dumps(identity,indent=2)+'\n')
print(attribution.query("window=='development'")[["strategy","cost_bps","relative_wealth","fixed_positions_gross_log_excess","incremental_fee_log_drag","turnover"]].to_string(index=False))
print(pd.DataFrame(active_decisions).to_string(index=False))
print(pd.DataFrame(episodes).query("strategy=='benchmark_terminal'").to_string(index=False))
print(pd.DataFrame(threshold).to_string(index=False))
