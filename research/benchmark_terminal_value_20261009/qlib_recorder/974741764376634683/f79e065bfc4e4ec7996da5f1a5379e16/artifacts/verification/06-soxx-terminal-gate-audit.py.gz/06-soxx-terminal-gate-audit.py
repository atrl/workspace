import os,sys,json,hashlib
from pathlib import Path
os.environ['MLFLOW_ALLOW_FILE_STORE']='true';sys.path.insert(0,'/Users/rziiiii/dev/workspace')
import numpy as np,pandas as pd
import qlib
from qlib.workflow import R
root=Path('/Users/rziiiii/dev/workspace');card=root/'research/benchmark_terminal_value_20261009';target=Path('/tmp/soxx-terminal-independent-audit.json');audit=json.loads(target.read_text());s=json.loads((card/'summary.json').read_text());plan=json.loads((card/'plan.json').read_text())
qlib.init(provider_uri=str(root/s['execution_provider_uri']),region='us',kernels=1)
with R.uri_context(s['recorder_uri']):
 rec=R.get_recorder(experiment_name=s['experiment'],recorder_id=s['recorder_id']);assert rec.client.get_run(rec.id).info.status=='FINISHED'
 art=Path(rec.get_local_dir())/'artifacts';objects={}
 for name in ['analysis/paths.pkl','analysis/raw_gates.pkl','analysis/gates.pkl']:
  assert hashlib.sha256((art/name).read_bytes()).hexdigest()==audit['artifact_sha256'][name]
  objects[name]=rec.load_object(name)
paths=objects['analysis/paths.pkl'];raw=objects['analysis/raw_gates.pkl']['benchmark_terminal'];resolved=objects['analysis/gates.pkl']['benchmark_terminal']

def metrics(r):
 l=np.log1p(r);nav=np.r_[0.,l.cumsum()];ordered=np.sort(r);mass=.05*len(r);k=int(np.floor(mass))
 return {'return_pct':100*np.expm1(l.sum()),'max_drawdown_pct':100*np.expm1((nav-np.maximum.accumulate(nav)).min()),'cvar5_pct':100*(ordered[:k].sum()+(mass-k)*ordered[k])/mass}
checks=[]
for cost in [10.,25.]:
 p=paths['benchmark_terminal',cost];b=paths['soxx',cost];sel=p.signal_date.dt.year.isin(plan['development_years']);r=p.loc[sel,'strategy_return'].to_numpy();rb=b.loc[sel,'strategy_return'].to_numpy();ex=np.log1p(r)-np.log1p(rb);years=p.loc[sel,'signal_date'].dt.year.to_numpy();annual=np.array([ex[years==y].sum() for y in plan['development_years']]);rolling=pd.Series(ex).rolling(252).sum().dropna();g=resolved['gates'].loc[resolved['gates'].cost_bps.eq(cost)].iloc[0];mr=raw['metrics'].loc[raw['metrics'].cost_bps.eq(cost)].iloc[0]
 for name,value in metrics(r).items():assert abs(mr[name]-value)<1e-10
 for name,value in metrics(rb).items():assert abs(mr['benchmark_'+name]-value)<1e-10
 np.testing.assert_array_equal(raw['annual'].loc[raw['annual'].cost_bps.eq(cost),'log_excess_sum'].to_numpy(),annual)
 assert mr.log_excess_sum==ex.sum() and mr.relative_wealth==np.exp(ex.sum())
 floor=plan['numerical_log_excess_floor'];defined={'aggregate_positive_net_log_excess':bool(ex.sum()>floor),'minimum_positive_signal_years':bool((annual>floor).sum()>=plan['gates']['minimum_positive_years']),'median_annual_log_excess_positive':bool(np.median(annual)>floor),'leave_any_one_year_out_log_excess_positive':bool((annual.sum()-annual).min()>floor),'anchored_max_drawdown_not_worse_than_soxx':metrics(r)['max_drawdown_pct']>=metrics(rb)['max_drawdown_pct']-1e-10,'cvar5_not_worse_than_soxx':metrics(r)['cvar5_pct']>=metrics(rb)['cvar5_pct']-1e-10,'minimum_rolling_positive_excess_rate':bool((rolling>floor).mean()>=plan['gates']['minimum_rolling_win_rate'])}
 for row in raw['bootstrap'].loc[raw['bootstrap'].cost_bps.eq(cost)].itertuples():defined[f'stationary_block_{row.mean_block}_lower_bound_positive']=bool(len(ex)*row.daily_lower_bound>floor)
 for name,value in defined.items():assert bool(g[name])==value,(name,g[name],value)
 assert bool(g.all_pass)==all(defined.values());checks.append({'cost_bps':cost,'all_independent_gate_checks_match':True,'all_pass':all(defined.values())})
annual_csv=pd.read_csv(card/'annual_metrics.csv');maximum=0.
for row in annual_csv.itertuples():
 p=paths[row.strategy,row.cost_bps];b=paths['soxx',row.cost_bps];mask=p.signal_date.dt.year.eq(row.year);r=p.loc[mask,'strategy_return'].to_numpy();rb=b.loc[mask,'strategy_return'].to_numpy();values=metrics(r);values['relative_wealth']=np.exp((np.log1p(r)-np.log1p(rb)).sum());values['turnover']=p.loc[mask,'turnover'].sum()
 error=max(abs(getattr(row,name)-value) for name,value in values.items());assert error<1e-8;maximum=max(maximum,error)
for row in audit['native_positions_independently_valued']:
 assert max(row['maximum_absolute_errors'].values())<=1e-10
for row in audit['solver_input_and_value_checks']:
 assert max(row['maximum_absolute_errors'].values())<=1e-10
extra={'all_gate_predicates_independently_recomputed':checks,'annual_rows_recomputed':len(annual_csv),'annual_metrics_maximum_absolute_error':maximum,'native_funding_identity_tolerance':1e-10,'saved_certificate_original_tolerance':1e-8,'new_bootstrap_samples':0,'policy_solves':0,'model_fits':0}
audit['additional_statistic_gate_audit']=extra;target.write_text(json.dumps(audit,indent=2,allow_nan=False)+'\n');print(json.dumps(extra,indent=2))
