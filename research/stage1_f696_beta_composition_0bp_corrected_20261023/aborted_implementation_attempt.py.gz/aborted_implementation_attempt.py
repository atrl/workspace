"""One corrected f696-parent nominal-beta composition 0bp account."""

from __future__ import annotations

import hashlib
import json
import shlex
from pathlib import Path

import numpy as np
import pandas as pd


OUTPUTS = ["soxl_weight", "soxx_weight", "cash_weight", "tail_probability", "alpha_probability"]
DATES = ["signal_date", "trade_date", "exit_date"]


def _sha(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def prepare(root: Path) -> dict:
    from qlib.workflow import R

    from src.workflow.stage1_nvda_guidance_receiver import prepare_account_sources

    root = Path(root).resolve()
    card = root / "research/stage1_f696_beta_composition_0bp_corrected_20261023"
    plan = json.loads((card / "plan.json").read_text())
    assert plan["frozen"] and plan["execution_authorized_by_active_Goal"]
    digest = _sha(card / "plan.json")
    for relative, expected in plan["code_identities"].items():
        assert _sha(root / relative) == expected, relative
    assert _sha(root / plan["identity_audit"]["path"]) == plan["identity_audit"]["sha256"]
    assert _sha(root / plan["provider_uri"] / "qlib_store_manifest.json") == plan["provider_manifest_sha256"]
    helper = root / plan["account_source_helper"]
    assert _sha(helper / "account_source_preflight.json") == plan["account_source_receipt_sha256"]
    account = prepare_account_sources(root=root, card=helper)
    assert _sha(helper / "account_source_preflight.json") == plan["account_source_receipt_sha256"]
    assert len(account["frame"]) == len(account["source_targets"]) == plan["required_parent_parity"]["rows"]
    source = plan["source_f696"]
    source_card = root / source["card"]
    assert _sha(source_card / "summary.json") == source["summary_sha256"]
    assert _sha(source_card / "qlib_recorder" / source["experiment_id"] /
                source["recorder_id"] / "artifacts/inputs/frame") == source["frozen_A_frame_artifact_sha256"]
    with R.uri_context(str((source_card / "qlib_recorder").resolve())):
        A_frame = R.get_recorder(experiment_name=source_card.name,
                                 recorder_id=source["recorder_id"]).load_object("inputs/frame")
    raw = account["frame"].reset_index(drop=True)
    A_frame = A_frame.reset_index(drop=True)
    target = account["source_targets"].copy()
    pd.testing.assert_index_equal(pd.DatetimeIndex(target.index), pd.DatetimeIndex(raw.signal_date),
                                  check_names=False)
    pd.testing.assert_frame_equal(raw[DATES], A_frame[DATES])
    mismatch = np.abs(raw[OUTPUTS].to_numpy(float) - A_frame[OUTPUTS].to_numpy(float)).max(axis=1)
    assert int((mismatch > 1e-8).sum()) == 944
    frame = raw.copy(deep=True)
    for name in OUTPUTS:
        frame[name] = target[name].to_numpy(copy=True)
    pd.testing.assert_frame_equal(frame[DATES], A_frame[DATES])
    np.testing.assert_allclose(frame[OUTPUTS].to_numpy(float), A_frame[OUTPUTS].to_numpy(float),
                               rtol=0, atol=0)
    if account["references"]["Stage1_A"]["audit"]["status"] != "passed":
        raise ValueError("exact original Stage1 A_0 native audit failed")
    if account["references"]["SOXX"]["audit"]["status"] != "passed":
        raise ValueError("exact SOXX native audit failed")
    receipt = {"status": "verified_exact_f696_944_row_five_output_parent",
               "plan_sha256": digest, "rows": len(frame),
               "raw_27baa_vs_f696_mismatch_rows": int((mismatch > 1e-8).sum()),
               "all_five_corrected_outputs_max_abs_error": 0.0,
               "source_A_recorder_id": source["recorder_id"],
               "source_helper_receipt_sha256": plan["account_source_receipt_sha256"],
               "new_fits": 0, "new_accounts": 0}
    (card / "preflight_result.json").write_text(json.dumps(receipt, indent=2) + "\n")
    return {"plan": plan, "account": account, "frame": frame, "receipt": receipt}


def run(root: Path) -> dict:
    from qlib.workflow import R

    from src.backtest.native_raw_corporate import native_raw_validate
    from src.backtest.stage1_domain_heads_raw import replay_stage1_raw
    from src.data.nas_market_data import _settings, _ssh, archive_nas_recorder
    from src.model.nominal_beta_composition import AuditedComposition
    from src.workflow.intraday_recovery_direct_allocation import IntradayRecoveryDirectAllocationSpec
    from src.workflow.stage1_open_action_value import Stage1OpenActionValueSpec
    from src.workflow.stage1_rolling126_shortfall import _analyze_account

    root = Path(root).resolve()
    card = root / "research/stage1_f696_beta_composition_0bp_corrected_20261023"
    if (card / "run_state.json").exists():
        raise ValueError("fixed corrected composition attempt already started")
    prepared = prepare(root)
    plan, account, frame = prepared["plan"], prepared["account"], prepared["frame"]
    state = {"status": "path_attempted", "plan_sha256": _sha(card / "plan.json"),
             "new_model_fits": 0, "path_attempts": 1, "native_account_attempts": 0,
             "bootstrap_attempts": 0}

    def save_state() -> None:
        (card / "run_state.json").write_text(json.dumps(state, indent=2) + "\n")

    save_state()
    recovery = IntradayRecoveryDirectAllocationSpec(root=root, **account["recovery_spec"])
    action = Stage1OpenActionValueSpec(root=root, **account["action_spec"])
    execution = {"initial_cash": plan["economics"]["initial_cash_usd"],
                 "tariff": account["parent"]["tariff"]}
    composition = AuditedComposition()
    path = replay_stage1_raw(frame, point_prices=account["points"], schedule=account["schedule"],
        plan=execution, controller=account["controller"], recovery_spec=recovery,
        action_spec=action, selection=account["selection"], slippage_bps=0,
        target_transform=composition)
    assert len(path["replay"]) == 944 and len(path["points"]) == 3778
    audit = pd.DataFrame(composition.rows)
    assert len(audit) > 0 and audit.beta_error.abs().max() <= 1e-12
    assert audit.simplex_error.abs().max() <= 1e-12
    state["status"] = "native_attempted"
    state["native_account_attempts"] = 1
    save_state()
    provider = root / plan["provider_uri"]
    book = native_raw_validate(path, provider_uri=provider, point_prices=account["points"],
        schedule=account["schedule"], tariff=execution["tariff"], cost=0,
        initial_cash=execution["initial_cash"])
    assert book["audit"]["status"] == "passed"
    for role in ("Stage1_A", "SOXX"):
        pd.testing.assert_frame_equal(book["authority"][DATES].reset_index(drop=True),
            account["references"][role]["authority"][DATES].reset_index(drop=True))
    state["status"] = "analysis_attempted"
    state["bootstrap_attempts"] = 1
    save_state()
    result = _analyze_account(
        account=book["authority"],
        reference_soxx=account["references"]["SOXX"]["authority"],
        reference_stage1=account["references"]["Stage1_A"]["authority"],
        sampled_drawdown=-100 * float(path["replay"].monitored_drawdown.max()),
        plan=plan,
    )
    audit_summary = {"transform_calls": len(audit),
                     "open_calls": int(audit.slot.eq("open").sum()),
                     "recovery_calls": int(audit.slot.eq("recovery").sum()),
                     "max_abs_beta_error": float(audit.beta_error.abs().max()),
                     "max_abs_simplex_error": float(audit.simplex_error.abs().max()),
                     "mean_before_cash": float(audit.before_cash.mean()),
                     "mean_after_cash": float(audit.after_cash.mean())}
    tracking = card / "qlib_recorder"
    with R.start(experiment_name=card.name, uri=str(tracking)):
        recorder = R.get_recorder()
        recorder.save_objects(artifact_path="inputs", plan=plan, preflight=prepared["receipt"],
                              source_helper_receipt=account["receipt"], audit_summary=audit_summary)
        recorder.save_objects(artifact_path="paths", candidate_0=path)
        recorder.save_objects(artifact_path="native", candidate_0=book)
        recorder.save_objects(artifact_path="analysis", metrics=result["SOXX_metrics"],
                              Stage1_increment=result["Stage1_increment_metrics"],
                              annual=result["annual"], quarter=result["quarter"],
                              rolling_summary=result["rolling_summary"],
                              uncertainty=result["uncertainty"], gates=result["gates"],
                              composition_audit=audit)
        recorder.save_objects(artifact_path="analysis/rolling", all_windows=result["rolling"])
        R.log_params(parent="f696_frozen_current_944_exact_outputs", added_slippage_bps=0)
        R.log_metrics(SOXX_relative_wealth=result["SOXX_metrics"]["relative_wealth"],
                      historical_0bp_pass=int(result["historical_0bp_gate_pass"]))
        rid, eid = recorder.id, str(recorder.experiment_id)
    state.update(status="finished", native_account_completed=1,
                 recorder_id=rid, experiment_id=eid)
    save_state()
    for key in ("annual", "quarter"):
        result[key].to_csv(card / (key + "_metrics.csv"), index=False)
    summary = {"experiment": card.name,
               "decision": ("historical_0bp_pass_needs_independent_review_2_5bp_forward"
                            if result["historical_0bp_gate_pass"]
                            else "not_promoted_fixed_corrected_f696_beta_composition_0bp"),
               "objective_achieved": False, "plan_sha256": _sha(card / "plan.json"),
               "source_parent": "f696_frozen_current_944_exact_outputs",
               "source_parent_identity_audit": plan["identity_audit"]["path"],
               "new_model_fits": 0, "new_native_accounts": 1,
               "gates": result["gates"], "SOXX_metrics": result["SOXX_metrics"],
               "Stage1_increment_metrics": result["Stage1_increment_metrics"],
               "rolling_summary": result["rolling_summary"],
               "uncertainty": result["uncertainty"], "composition_audit": audit_summary,
               "recorder_id": rid, "experiment_id": eid,
               "artifact_policy": {"policy": "slim_card_recorder_first", "workflow_config": "workflow.yaml",
                                   "recorder_only_artifacts": ["inputs/*", "paths/*", "native/*",
                                                               "analysis/rolling/*", "analysis/composition_audit"]},
               "limitations": ["2023-2026 history is reused development feedback.",
                               "Available raw point marks are not full-minute continuous risk certification.",
                               "2/5bp and qualified independent forward need separate execution after 0bp pass."]}
    source_card = root / plan["source_f696"]["card"]
    binding = json.loads((source_card / "nas_binding.json").read_text())
    binding.pop("evidence", None)
    (card / "nas_binding.json").write_text(json.dumps(binding, ensure_ascii=False, indent=2) + "\n")
    nas = archive_nas_recorder(card / "nas_binding.json", workspace_root=root,
                               card=card, recorder_id=rid, experiment_id=eid)
    remote = _ssh(_settings(root)["ssh"], "sha256sum " + shlex.quote(nas["nas_path"])).split()[0]
    assert remote == nas["sha256"]
    summary["NAS_evidence"] = nas
    summary["NAS_readback"] = {"verified": True, "sha256": remote}
    (card / "summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2) + "\n")
    (card / "workflow.yaml").write_text("experiment: " + card.name + "\nplan: plan.json\n"
        "parent: exact f696 frozen_current outputs and A_0 native reference\n"
        "provider_uri: " + plan["provider_uri"] + "\ncost_path: 0bp_plus_IBKR_Tiered\n")
    metrics = result["SOXX_metrics"]
    (card / "conclusion.md").write_text(
        "# 纠正父本后的 f696 Stage1 名义 beta 组成：0bp 原生账户\n\n"
        "执行前将 helper 的27baa五输出全部换成 `frozen_current`，与原 A_0 来源 944/944 日逐值一致；"
        "随后仅使用固定名义beta组成公式，完整 b472 动作/风控/恢复链与原股数公司行动账本，"
        "0bp 额外滑点但照收 IBKR Tiered 费用。0拟合、1新独立原生账户。\n\n"
        f"候选/SOXX 期末净财富比 {metrics['relative_wealth']:.6f}，"
        f"相对原 f696 A_0 财富比 {result['Stage1_increment_metrics']['relative_wealth']:.6f}。"
        f"收盘最大回撤 {metrics['max_drawdown_pct']:.3f}%，可用点回撤 "
        f"{-100*float(path['replay'].monitored_drawdown.max()):.3f}%；"
        f"CVaR5 {metrics['cvar5_pct']:.3f}% 对 SOXX {metrics['benchmark_cvar5_pct']:.3f}%。"
        f"完整年、126日窗口及SOXX区块下界见 `summary.json` 和Recorder。"
        f"决定 `{summary['decision']}`。\n\n"
        "2023–2026 为复用历史，不是独立前向。若0bp门失败，关闭本固定版本，"
        "不调转换比例/风险阈值；若通过，还需独立复核、单独2/5bp及合格前向。"
        f"Recorder `{rid}`，NAS SHA `{remote}`。\n")
    return summary
